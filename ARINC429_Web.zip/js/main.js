const instrumentoSelect = document.getElementById("instrumento");
const imgDisplay = document.getElementById("imgDisplay");
const enviarBtn = document.getElementById("enviar");
const valorInput = document.getElementById("valor");
const mensaje = document.getElementById("mensaje");

const instrumentos = {
    altimetro: "images/altimetro.png",
    velocimetro: "images/velocimetro.png",
    horizonte: "images/horizonte.png",
    brujula: "images/brujula.png"
};

instrumentoSelect.addEventListener("change", () => {
    const valor = instrumentoSelect.value;
    imgDisplay.src = instrumentos[valor];
    imgDisplay.alt = valor;
});

enviarBtn.addEventListener("click", () => {
    const instrumento = instrumentoSelect.value;
    const valor = valorInput.value;

    if(valor === "") {
        mensaje.textContent = "Ingrese un valor antes de enviar.";
        mensaje.style.color = "red";
        return;
    }

    console.log(`Instrumento: ${instrumento}, Valor: ${valor}`);
    mensaje.textContent = `Valor ${valor} del instrumento ${instrumento} enviado al servidor.`;
    mensaje.style.color = "green";

    valorInput.value = "";
});